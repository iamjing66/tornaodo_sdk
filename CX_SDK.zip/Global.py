#!/usr/bin/env python
# coding=utf-8
import os


TLMaxNum = 5        #时间收益体力最大数
TLTimeLong = 600    #体力倒计时
COOKIES_TLONG = 600  #cookie有效时间

WechatAppId = "wx249be41a361e73fe"
Wechatsecret = "1a2d557e5a6337f39d0496262f2ed123"
WechatLoginUrl = "https://api.weixin.qq.com/sns/jscode2session?appid={0}&secret={1}&js_code={2}&grant_type=authorization_code"
WechatDYUrl = "https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token={0}"
WechatAccessToken = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={0}&secret={1}"
WechatKFMsgUrl = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={0}"

SolrUrl = "192.168.0.9:8099"    #索引库日志

settings = dict(
    template_path = os.path.join(os.path.dirname(__file__), "templates"),
    static_path = os.path.join(os.path.dirname(__file__), "statics"),
    cookie_secret = "bZJc2sWbQLKos6GkHn/VB9oXwQt8S0R0kRvJ5/xJ89E=",
    xsrf_cookies = False,
    login_url = '/',
    log_file=os.path.dirname(__file__)+"/tornado.log",
    )


# 数据库配置参数
mysql_options = dict(
    host="192.168.0.9",
    database="createx_kbe",
    user="root",
    password="root"
)

JSON_Bck = {
            "Code":0,
            "Msg":"",
            "Data":""
        }

Verify_Msg = {
    "-11":"APPID 参数异常",
    "-12":"APPID 未申请",
    "-13":"APPID 已到期",
    "-14":"流量已用完",
    "-21":"账号不存在",
    "-22":"账号到期",
    "-23":"账号异常，怀疑不是自己操作",
    "-24":"参数异常"
}

def GetObjTableName(uid,pid):
    return "tb_obj_"+str(uid)+"_"+str(pid)

def GetMObjTableName(uid,pid):
    return "tb_mobj_"+str(uid)+"_"+str(pid)

def GetExtraTableName(uid,pid):
    return "tb_extra_"+str(uid)+"_"+str(pid)

def GetMExtraTableName(uid,pid):
    return "tb_mextra_"+str(uid)+"_"+str(pid)

def GetLessonTableName(uid,pid):
    return "tb_lesson_"+str(uid)+"_"+str(pid)

def GetMLessonTableName(uid,pid):
    return "tb_mlesson_"+str(uid)+"_"+str(pid)

def GetWorkLogTableName(uid,pid):
    return "tb_work_log_"+str(uid)+"_"+str(pid)

def GetCourseLogTableName(uid,pid,lid):
    return "tb_course_log_"+str(uid)+"_"+str(pid)+"_"+str(lid)

def GetSisLogTableName(cid):
    return "tb_sis_log_"+cid

def GetWorkZanTableName(uid,pid):
    return "tb_work_zan_"+str(uid)+"_"+str(pid)

def GetCourseZanTableName(uid,pid,lid):
    return "tb_course_zan_"+str(uid)+"_"+str(pid)+"_"+str(lid)

def GetSisZanTableName(cid):
    return "tb_sis_zan_"+cid