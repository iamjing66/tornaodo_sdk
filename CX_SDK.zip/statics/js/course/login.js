$(document).ready(function(){
            alert("aaaaa");
          $("p").click(function(){
            $(this).hide();
          });
});

