#!/usr/bin/env python
# coding=utf-8
"""
the url structure of website
"""


from handlers.index import IndexHandler    #假设已经有了
from handlers.pget import plistHandler
from handlers.pget import clistHandler
from handlers.pget import wlistHandler
from handlers.pget import pcheckHandler
from handlers.pget import pdataHandler
from handlers.pget import plistINIHandler
from handlers.pget import pdataIniHandler
from handlers.pget import lcheckHandler
from handlers.pget import ldataHandler
from handlers.sget import s_clistHandler
from handlers.sget import s_wlistHandler
from handlers.sget import s_pcheckHandler
from handlers.sget import s_pdataHandler
from handlers.sget import s_lcheckHandler
from handlers.sget import s_ldataHandler
from handlers.cxlog import writeLogHandler
from handlers.ppost import post_plistINIHandler
from handlers.ppost import post_pcheckHandler
from handlers.ppost import post_pdataIniHandler
from handlers.apppost import apppost_LoginINIHandler
from handlers.apppost import apppost_PDataINIHandler

#统一用户体系
#http://192.168.0.9:9001/pget/pdata?appid=fd17cb08-1824-11eb-a7df-408d5cf8276a&username=lyy&gpid=5&guid=24&gtype=0

#无用户体系
#http://192.168.0.9:9001/sget/pdata?appid=fd17cb08-1824-11eb-a7df-408d5cf8276a&gpid=5&guid=24&gtype=0

Urls = [
    ('/', IndexHandler),
    #====以下url-需要用户接入是 跟 编程有统一账号体系，并且 账号是作为参数传入
    ('/pget/plist', plistHandler),          #自由工程列表获取                       pam: appid(SDK的appid) username(获取数据的用户名)
    ('/pget/plist/ini', plistINIHandler),          #自由工程列表获取                       pam: appid(SDK的appid) username(获取数据的用户名)
    ('/pget/clist', clistHandler),          #标准课程列表获取                       pam: appid(SDK的appid) username(获取数据的用户名)
    ('/pget/wlist', wlistHandler),          #共享作品列表获取                       pam: appid(SDK的appid) username(获取数据的用户名)
    #('/pget/pcheck', pcheckHandler),        #获取工程版本号(用来给客户端一个标记)   pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/sget/lcheck', pcheckHandler),        #获取工程版本号(用来给客户端一个标记)   pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/pget/pdata', pdataHandler),          #获取工程数据(json)                     pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    #('/pget/pdata/ini', pdataIniHandler),   #获取工程数据(ini)                      pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/sget/pdata/ini', pdataIniHandler),          #获取工程数据(json)                     pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/pget/lcheck', lcheckHandler),        #获取课时版本号(用来给客户端一个标记)   pam: appid(SDK的appid) username(获取数据的用户名)  gcid(课程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/pget/ldata', ldataHandler),          #获课时数据                             pam: appid(SDK的appid) username(获取数据的用户名)  gcid(课程ID) guid(工程作者UID) gtype(0-本地 1-市场)


    #====以下url-无需接入用户，没有制作者一说，第三方直接可通过APPID来获取数据
    ('/sdk/noc/clist', s_clistHandler),         #课程市场获取                           pam: appid(SDK的appid)
    ('/sdk/noc/wlist', s_wlistHandler),         #课程市场获取                           pam: appid(SDK的appid)
    ('/sdk/noc/pcheck',s_pcheckHandler),        #获取工程版本号(用来给客户端一个标记)   pam: appid(SDK的appid) gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/sdk/noc/pdata', s_pdataHandler),         #获取工程数据                           pam: appid(SDK的appid) gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/sdk/noc/lcheck', s_lcheckHandler),       #获取课时版本号(用来给客户端一个标记)   pam: appid(SDK的appid) gcid(课程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/sdk/noc/ldata', s_ldataHandler),         #获课时数据                             pam: appid(SDK的appid) gcid(课程ID) guid(工程作者UID) gtype(0-本地 1-市场)



    #===以下URL用来接入-XRCREATEX编程 -     POST请求 - 需要带用户
    ('/ppost/logindata', post_plistINIHandler),         #自由工程列表获取                           pam: appid(SDK的appid) username(获取数据的用户名)
    ('/ppost/pcheck', post_pcheckHandler),              #获取工程版本号(用来给客户端一个标记)        pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)
    ('/ppost/pdata/ini', post_pdataIniHandler),         #获取工程数据(json)                       pam: appid(SDK的appid) username(获取数据的用户名)  gpid(工程ID) guid(工程作者UID) gtype(0-本地 1-市场)

    #===以下URL用来接入-XR云课堂 -           POST请求 - 需要带用户
    ('/apppost/logindata', apppost_LoginINIHandler),    #登录数据获取                       pam: appid(SDK的appid) username(获取数据的用户名)
    ('/apppost/pdata/ini', apppost_PDataINIHandler),    #工程数据                       pam: appid(SDK的appid) username(获取数据的用户名)

    #====以下url-为日志接口
    ('/cxlog/com', writeLogHandler),         #编程写入日志





]