#!/usr/bin/env python
# coding=utf-8

from url import Urls
import Global
import logging
import hashlib
import methods.SolrInterface as sinter
import tornado.web
import threading
from methods.db_mysql import DbHander


#############
#本服务用来负责读操作
#############


class Application(tornado.web.Application):

    def __init__(self, *args, **kwargs):
        super(Application, self).__init__(*args, **kwargs)

        #缓存长连接池 - 模式 - 用来处理，
        #*固定维护几个长连接，来处理一些非常频繁的业务
        self.db_list = [DbHander.DBREAD(),DbHander.DBREAD(),DbHander.DBREAD(),DbHander.DBREAD(),DbHander.DBREAD()]
        self.db_pair = 0
        self.db = None
        self.Cur = None

        self.post_data_temp_post = {}

        # self.Ali_Order = 1
        # self.SolrInst = sinter.SolrInterface()
        self.AppData = {}
        t = threading.Timer(1, self.CkDb)
        t.start()


    def DBPing(self):

        self.db = self.db_list[self.db_pair]
        self.db.ping(reconnect=True)
        self.Cur = self.db.cursor()
        self.db_pair += 1
        if self.db_pair > 4:
            self.db_pair = 0


    def CkDb(self):
        # Do something

        ck_sql = "select ID,APPID,FLOW,PASSDATE,FLOW_USE,appCertificate from tb_cxsdk_users;"
        self.DBPing()
        self.Cur.execute(ck_sql)
        self.db.commit()
        lines = self.Cur.fetchall()
        if lines and len(lines) > 0:
            for arr_info in lines:

                APPID = arr_info[1]
                appandcertificate = hashlib.md5((APPID+arr_info[5]).encode()).hexdigest()
                print(appandcertificate)
                if appandcertificate not in self.AppData:
                    self.AppData[appandcertificate] = {
                        "ID":int(arr_info[0]),
                        "APPID": arr_info[1],
                        "FLOW":int(arr_info[2]),
                        "PASSDATE": arr_info[3],
                        "FLOW_USE": int(arr_info[4]),
                        "appCertificate":arr_info[5]
                    }
                else:
                    self.AppData[appandcertificate]["FLOW"] = int(arr_info[2])
                    self.AppData[appandcertificate]["PASSDATE"] = arr_info[3]
                    self.AppData[appandcertificate]["FLOW_USE"] = int(arr_info[4])
                    self.AppData[appandcertificate]["appCertificate"] = arr_info[5]

        print(self.AppData)
        logging.info("AppData - Geted")

        t = threading.Timer(60,self.CkDb)
        t.start()


App = Application(
    handlers = Urls,
    **Global.settings
    )