#!/usr/bin/env python
# coding=utf-8

import pysolr
import datetime
import Global

class SolrInterface:

    # 智慧豆消费日志
    # proType 1：充值 2：分发 3：赠送 4：VIP购买 5：资源购买 6：课程购买 7：场景购买 8：作品购买 9：APP端买看 10:app端购买sis课程
    # terminal 账号来源 0-PC 1-APP 2-VR
    # proName 项目名称
    # proPay  消费金额
    # supplement 补充
    def Log_Cost(self,UID,organization,distributor, proType, proName, proPay, supplement, cName, classification):

        try:
            solr = pysolr.Solr('http://' + Global.SolrUrl + '/scoreDataCore', timeout=10)
            # How you'd index data.
            _data = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
            solr.add([
                {
                    "UID": UID,
                    "dateTime": _data,
                    "organization": organization,
                    "distributor": distributor,
                    "proType": proType,
                    "terminal ": 1,
                    "proName": proName,
                    "proPay": proPay,
                    "cName": cName,
                    "classification": classification,
                    "supplement": supplement,
                    "scoreDataCore": 1
                }
            ])
            solr.commit()
        except:
            print("Log_Cost Error")
        else:
            print("Log_Cost OK")



