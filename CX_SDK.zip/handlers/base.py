#! /usr/bin/env python
# coding=utf-8

import tornado.web
import json
import time
import logging
import Global
import copy
from methods.db_mysql import DbHander

class BaseHandler(tornado.web.RequestHandler):


    def __init__(self, application, request, **kwargs):

        tornado.web.RequestHandler.__init__(self,application, request, **kwargs)
        self.AppID = ""
        self.UserName = ""
        self.JData = None
        #self.post_data_temp = []
        self.OnePageNum = 20

    def get_current_user(self):
        return self.get_secure_cookie("user")

    #自定义日志格式
    # def _request_summary(self):
    #     if self.request.method == 'post':
    #         return "%s %s (%s@%s)" % (self.request.method, self.request.uri,
    #                                   self._operator_name, self.request.remote_ip)
    #
    #     return "%s %s %s(%s@%s)" % (self.request.method, self.request.uri, self.request.body.decode(),
    #                                 self._operator_name, self.request.remote_ip)
    def post_data_temp_init(self,uid):
        if uid in self.application.post_data_temp_post:
            del self.application.post_data_temp_post[uid]

    def post_data_temp_get(self,uid):
        if uid in self.application.post_data_temp_post:
            return self.application.post_data_temp_post[uid]
        return []

    def post_data_temp_set(self,uid,data):

        # _arr = []
        # if uid in self.application.post_data_temp_post:
        #     _arr = self.application.post_data_temp_post[uid]
        # _arr.append(data)
        self.application.post_data_temp_post[uid] = data

    @property
    def ali_client(self):
        return self.application.aliclient

    @property
    def ali_model(self):
        return self.application.alimodel

    @property
    def wechat_client(self):
        return self.application.wechatclient

    @property
    def db_ping(self):
        """作为RequestHandler对象的db属性"""
        self.application.DBPing()

    @property
    def Cur(self):
        return self.application.Cur


    @property
    def db(self):
        """作为RequestHandler对象的db属性"""
        return self.application.db


    @property
    def Ali_Order(self):
        return self.application.Ali_Order

    @property
    def SolrInst(self):
        return self.application.SolrInst

    @property
    def App_ID(self):
        return self.get_argument("appid")

    @property
    def USERNAME(self):
        return self.get_argument("username")

    @property
    def VERIFY_SMAIN(self):

        _appid = self.App_ID
        cxsdk_appid = self.get_cookie("cxsdk_appid")
        cxsdk_pdate = self.get_cookie("cxsdk_pdate")
        if cxsdk_pdate != None:
            cxsdk_pdate = int(cxsdk_pdate)
        if cxsdk_appid != None and cxsdk_pdate != None:
            logging.info("Get cxsdk_appid:%s cxsdk_pdate:%i " % (cxsdk_appid, cxsdk_pdate))
            if cxsdk_appid == _appid:
                if int(time.time()) - cxsdk_pdate < Global.COOKIES_TLONG:
                    logging.info("Cookieing Bcked")
                    return 1

        _UID = self.VERIFY(0)
        logging.info("Cookieed Computeing")
        if _UID <= 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = _UID
            JSON_Bck["Msg"] = Global.Verify_Msg[str(_UID)]
            self.write(JSON_Bck)
        else:
            logging.info("Set - cxsdk_appid:%s cxsdk_pdate:%i " % (_appid, int(time.time())))
            self.set_cookie("cxsdk_appid", _appid)
            self.set_cookie("cxsdk_pdate", str(int(time.time())))
        return _UID

    @property
    def VERIFY_MAIN(self):

        _username = self.USERNAME

        cxsdk_username = self.get_cookie("cxsdk_username")
        cxsdk_pdate = self.get_cookie("cxsdk_pdate")
        cxsdk_uid = self.get_cookie("cxsdk_uid")
        if cxsdk_pdate != None:
            cxsdk_pdate = int(cxsdk_pdate)
        if cxsdk_uid != None:
            cxsdk_uid = int(cxsdk_uid)
        if cxsdk_username != None and cxsdk_pdate != None and cxsdk_uid != None and cxsdk_uid != 0:
            logging.info("Get cxsdk_username:%s cxsdk_pdate:%i cxsdk_uid:%i" % (cxsdk_username, cxsdk_pdate, cxsdk_uid))
            if cxsdk_username == _username:
                if int(time.time()) - cxsdk_pdate  < Global.COOKIES_TLONG:
                    logging.info( "Cookieing Bcked")
                    return cxsdk_uid

        _UID = self.VERIFY(1)
        logging.info("Cookieed Computeing")
        if _UID <= 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = _UID
            JSON_Bck["Msg"] = Global.Verify_Msg[str(_UID)]
            self.write(JSON_Bck)
        else:
            logging.info("Set - cxsdk_username:%s cxsdk_pdate:%i cxsdk_uid:%i" % (_username, int(time.time()), _UID))
            self.set_cookie("cxsdk_username",_username)
            self.set_cookie("cxsdk_pdate", str(int(time.time())))
            self.set_cookie("cxsdk_uid", str(_UID))
        return _UID

    def VERIFY(self,type):

        if type == 2:
            APPID = self.AppID
        elif type == 3:
            APPID = self.AppID
        else:
            APPID = self.App_ID
        print("APPID:",APPID)
        if APPID == "" or len(APPID) < 1:
            return -11 #APPID 参数异常
        appdata = self.application.AppData
        if APPID not in appdata:
            return -12  # APPID 未申请，请联系管理员
        data = appdata[APPID]
        #验证下APPIP是否到期了
        timeStamp = int(data["PASSDATE"].timestamp())
        print(timeStamp)
        if timeStamp < time.time():
            return -13  # APPID 已到期 请联系管理
        if data["FLOW_USE"] >= data["FLOW"] and data["FLOW"] != -1:
            return -14  # 流量已用完

        if type == 0 or type == 3:
            return 1
        else:
            return self.VerifyIdentity(type)


    def VerifyIdentity(self,type):

        if type == 2:
            username = self.UserName
        else:
            username = self.USERNAME
        sql_str = "select T1.UID,T1.ENDDATE from tb_userdata AS T1 INNER JOIN kbe_accountinfos as T2 ON T1.USERNAME = T2.AccountName AND T1.UserName = '"+username+"';"

        #print("sql_str",sql_str)
        #self.db_ping
        db = DbHander.DBREAD()
        Cur = db.cursor()
        Cur.execute(sql_str)
        db.commit()
        _uid = 0
        _enddate = 0
        data = Cur.fetchone()
        if data != None and len(data) > 0:
            _uid = int(data[0])
            _enddate = int(data[1])
        db.close()
        if _uid == 0:
            return -21 #账号不存在
        if _enddate != 1 and _enddate < time.time():
            return -22  #账号到期
        # if password != _password:
        #     return -23  #账号异常，怀疑不是自己操作
        logging.info("UID : %i" % _uid)
        return _uid  #成功

    @property
    def POST_VERIFY_MAIN(self):

        #print("asdasdasd")
        post_data = json.loads(self.request.body.decode('utf-8'))
        #print("post_data", post_data, post_data["appid"], post_data["username"])
        if post_data == None or 'appid' not in post_data.keys():
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = -24
            JSON_Bck["Msg"] = Global.Verify_Msg[str(-24)]
            self.write(JSON_Bck)
            return 0
        self.UserName = post_data["username"]
        self.AppID = post_data["appid"]
        self.JData = post_data["pdata"]

        cxsdk_username = self.get_cookie("cxsdk_username")
        cxsdk_pdate = self.get_cookie("cxsdk_pdate")
        cxsdk_uid = self.get_cookie("cxsdk_uid")
        if cxsdk_pdate != None:
            cxsdk_pdate = int(cxsdk_pdate)
        if cxsdk_uid != None:
            cxsdk_uid = int(cxsdk_uid)
        if cxsdk_username != None and cxsdk_pdate != None and cxsdk_uid != None and cxsdk_uid != 0:
            logging.info("Get cxsdk_username:%s cxsdk_pdate:%i cxsdk_uid:%i" % (cxsdk_username, cxsdk_pdate, cxsdk_uid))
            if cxsdk_username == self.UserName:
                if int(time.time()) - cxsdk_pdate < Global.COOKIES_TLONG:
                    logging.info("Cookieing Bcked")
                    return cxsdk_uid

        _UID = self.VERIFY(2)
        logging.info("Cookieed Computeing")
        if _UID <= 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = _UID
            JSON_Bck["Msg"] = Global.Verify_Msg[str(_UID)]
            self.write(JSON_Bck)
        else:
            logging.info("Set - cxsdk_username:%s cxsdk_pdate:%i cxsdk_uid:%i" % (self.UserName, int(time.time()), _UID))
            self.set_cookie("cxsdk_username", self.UserName)
            self.set_cookie("cxsdk_pdate", str(int(time.time())))
            self.set_cookie("cxsdk_uid", str(_UID))
        return _UID

    @property
    def POSTNOACCOUNT_VERIFY_MAIN(self):

        post_data = json.loads(self.request.body.decode('utf-8'))
        print("post_data", post_data, post_data["appid"])
        if post_data == None or 'appid' not in post_data.keys():
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = -24
            JSON_Bck["Msg"] = Global.Verify_Msg[str(-24)]
            self.write(JSON_Bck)
            return 0
        self.AppID = post_data["appid"]
        self.JData = post_data["pdata"]
        _appid = self.AppID
        cxsdk_appid = self.get_cookie("cxsdk_appid")
        cxsdk_pdate = self.get_cookie("cxsdk_pdate")
        if cxsdk_pdate != None:
            cxsdk_pdate = int(cxsdk_pdate)
        if cxsdk_appid != None and cxsdk_pdate != None:
            logging.info("Get cxsdk_appid:%s cxsdk_pdate:%i " % (cxsdk_appid, cxsdk_pdate))
            if cxsdk_appid == _appid:
                if int(time.time()) - cxsdk_pdate < Global.COOKIES_TLONG:
                    logging.info("Cookieing Bcked")
                    return 1
        _UID = self.VERIFY(3)
        logging.info("Cookieed Computeing")
        if _UID <= 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Bck["Code"] = _UID
            JSON_Bck["Msg"] = Global.Verify_Msg[str(_UID)]
            self.write(JSON_Bck)
        else:
            logging.info("Set - cxsdk_appid:%s cxsdk_pdate:%i " % (_appid, int(time.time())))
            self.set_cookie("cxsdk_appid", _appid)
            self.set_cookie("cxsdk_pdate", str(int(time.time())))
        return _UID


    # def prepare(self):
    #     """预解析json数据"""
    #     if self.request.headers.get("Content-Type", "").startswith("application/json"):
    #         self.json_args = json.loads(self.request.body)
    #     else:
    #         self.json_args = {}

