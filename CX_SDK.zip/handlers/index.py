#!/usr/bin/env python
# coding=utf-8

import tornado.escape
from handlers.base import BaseHandler

class IndexHandler(BaseHandler):    #继承base.py中的类BaseHandler
    def get(self):

        # err_data = []
        #
        # sql = "select * from tb_res_error group by (ResType)  order by id desc limit 0,50;"
        # self.Cur.execute(sql)
        # self.db.commit()
        # data = self.Cur.fetchall()
        # if data != None and len(data) > 0:
        #     list_data = list(data)
        #     for minfo in list_data:
        #         minfo_list = list(minfo)
        #         _data = {
        #             "ID": str(minfo_list[0]),
        #             "ResID": str(minfo_list[1]),
        #             "Error_Log": str(minfo_list[2]),
        #             "ResType": str(minfo_list[3]),
        #             "Date": str(minfo_list[4])
        #         }
        #         err_data.append(_data)
        self.render("login.html")
    def post(self):

        ID = self.request.body_arguments["ID"][0].decode()
        self.db_ping
        sql = "delete from tb_res_error where ResType = (select n.ResType from (select ResType from tb_res_error where ID = "+ID+") as n );"
        self.Cur.execute(sql)
        self.db.commit()
        data = { "error":"" }
        self.write(data)




class ErrorHandler(BaseHandler):    #增加了一个专门用来显示错误的页面
    def get(self):                                        #但是后面不单独讲述，读者可以从源码中理解
        self.render("error.html")