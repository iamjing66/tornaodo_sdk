#!/usr/bin/env python
# coding=utf-8

import tornado.web
import tornado.escape
from handlers.base import BaseHandler

class UserHandler(BaseHandler):


    def post(self):
        # 获取参数
        mobile = self.json_args.get("mobile")
        password = self.json_args.get("passwd")
        print(mobile)
        print(password)

        # 检查参数
        # if not all([mobile, password]):
        #     return self.write(dict(errcode="4001", errmsg="参数错误"))
        # if not re.match(r"^1\d{10}$", mobile):
        #     return self.write(dict(errcode=RET.DATAERR, errmsg="手机号错误"))

        # 检查秘密是否正确
        # res = self.db.get("select up_user_id,up_name,up_passwd from ih_user_profile where up_mobile=%(mobile)s",
        #                   mobile=mobile)
        # password = hashlib.sha256(password + config.passwd_hash_key).hexdigest()
        if mobile == "admin" and password == "admin":
            # 生成session数据
            # 返回客户端
            return self.write(dict(errcode="0", errmsg="OK"))
        else:
            return self.write(dict(errcode="4004", errmsg="账号或密码错误！"))


class CourseHandler(BaseHandler):

        def get(self):
            self.render("course.html")