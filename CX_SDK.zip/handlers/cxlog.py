#!/usr/bin/env python
# coding=utf-8

import logging
import copy
import Global
import json
from handlers.base import BaseHandler
from methods.db_mysql import DbHander

class writeLogHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #课程列表
    def get(self):

        # uid = self.get_argument("uid")
        # username = self.get_argument("username")
        # #print("username",username,type(username))
        #
        # #print("============================================================")
        # # print(type(uid))
        # if uid == "":
        #     uid = "0"
        # ip = self.get_argument("ip")
        # apptype = self.get_argument("apptype")
        # cdate = self.get_argument("cdate")
        # title = self.get_argument("title")
        # comments = self.get_argument("comments")
        # servertype = self.get_argument("stype")
        # if "'" in username:
        #     username = comments
        # sql_str = "INSERT INTO `cxlog_com`(`UID`,`USERNAME`,`IP`,`CDATE`,`LOG_TITLE`,`LOG_COMMENTS`,`APPTYPE`,`SERVERTYPE`) values ("+uid+",'"+username+"','"+ip+"','"+cdate+"','"+title+"','"+comments+"','"+apptype+"','"+servertype+"');"
        # #print("sql_str",sql_str)
        # self.Cur.execute(sql_str)
        # self.db.commit()

        self.write("OK")


    def post(self):
        post_data = json.loads(self.request.body.decode('utf-8'))
        print("post_data - :",post_data)
        uid = post_data["uid"]
        username = post_data["username"]
        ip = post_data["ip"]
        apptype = post_data["apptype"]
        cdate = post_data["cdate"]
        title = post_data["title"]
        comments = post_data["comments"]
        servertype = post_data["stype"]
        #self.db_ping
        db = DbHander.DBREAD()
        Cur = db.cursor()
        if "'" in username:
            username = comments
        sql_str = "INSERT INTO `cxlog_com`(`UID`,`USERNAME`,`IP`,`CDATE`,`LOG_TITLE`,`LOG_COMMENTS`,`APPTYPE`,`SERVERTYPE`) values ("+uid+",'"+username+"','"+ip+"','"+cdate+"','"+title+"','"+comments+"','"+apptype+"','"+servertype+"');"
        #print("sql_str",sql_str)
        Cur.execute(sql_str)
        db.commit()
        db.close()
        self.write("OK")
