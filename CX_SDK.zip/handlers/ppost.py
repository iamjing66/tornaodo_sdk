#!/usr/bin/env python
# coding=utf-8

import logging
import copy
import Global
import json
from handlers.base import BaseHandler
from methods.db_mysql import DbHander

class post_plistINIHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #工程列表
    def post(self):


        UID = self.POST_VERIFY_MAIN

        p_back = ""
        if UID > 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Data = {}

            # BODY=====================================
            #获取 工程列表

            pdata = json.loads(self.JData)
            #print("pdata : ",pdata)
            read_type = int(pdata["rtype"])
            read_page = int(pdata["page"])

            print("read_type",read_type,"read_page",read_page)

            if read_page == 1:

                #self.post_data_temp_init()


                if read_type == 1:  #自由工程数据
                    self.post_data_temp_set(UID,self.GetPDataWVersion(pdata["data"],UID, 0))
                elif read_type == 2:  #本地作品数据
                    self.post_data_temp_set(UID,self.GetWDataWithVersion(pdata["data"],UID, 0))
                elif read_type == 3:  #本地课程数据
                    self.post_data_temp_set(UID,self.GetLessonDataWithVersion(pdata["data"],UID, 0,0))
                elif read_type == 4:  #课程购买数据
                    self.post_data_temp_set(UID,self.GetLessonDataWithVersion(pdata["data"],UID, 1,0))
                elif read_type == 5:  #课程市场
                    self.post_data_temp_set(UID,self.GetLessonDataWithVersion(pdata["data"],UID, 2,1))
                elif read_type == 6:  #作品市场数据
                    self.post_data_temp_set(UID,self.GetWDataWithVersion(pdata["data"],UID, 1))
                elif read_type == 7:  #下架的课程数据
                    self.post_data_temp_set(UID,self.DosGetsCourse())

            post_data_temp = self.post_data_temp_get(UID)
            ionly = len(post_data_temp) - read_page
            print(len(post_data_temp), ionly)
            JSON_Bck["Code"] = 1
            JSON_Bck["Data"] = post_data_temp[read_page-1]
            JSON_Bck["Msg"] = str(ionly)
            # BODY=====================================

            self.write(JSON_Bck)


    def DosGetsCourse(self):

        _back = ""
        ipos = 0
        temp_post = []

        db = DbHander.DBREAD()
        Cur = db.cursor()

        sql = "select cid,mlessonId,uid,flag from sys_course_res where flag = 0"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                if _back == "":
                    if len(temp_post) > 0:
                        _back = _back + "^"
                    _back = str(minfo_list[0])  + "`" + str(minfo_list[1]) + "`" + str(minfo_list[2]) + "`"  + str(minfo_list[3])
                else:
                    _back = _back + "^" + str(minfo_list[0])  + "`" + str(minfo_list[1]) + "`" + str(minfo_list[2]) + "`"  + str(minfo_list[3])
                ipos += 1
                if ipos % self.OnePageNum == 0:
                    temp_post.append(_back)
                    _back = ""
        temp_post.append(_back)
        db.close()
        return temp_post

    def GetLessonDataWithVersion(self,pdata,theuid,itype,objtype):

        p_server = {}
        obj_server = {}
        temp_post = []
        ipos = 0
        if pdata != None and len(pdata) > 0:
            l_pdata = pdata.split('*')
            for info in l_pdata:
                sdata = info.split('^')
                uid = int(sdata[0])
                pid = int(sdata[1])
                version = int(sdata[2])
                if uid not in p_server.keys():
                    p_server[uid] = {}
                    obj_server[uid] = {}
                p_server[uid][pid] = version
                if sdata[3] != "" and len(sdata[3]) > 0:
                    obj_server[uid][pid] = sdata[3]

        _lback = []
        pids = []
        _server_pid = {}
        _back = ""
        if itype == 0:
            sql = "select * from tb_course_bag where uid = " + str(theuid) + " and P_UID = 0"
        elif itype == 1:
            sql = "select * from tb_course_bag where uid = " + str(theuid) + " and P_UID != 0"
        elif itype == 2:
            sql = "select * from tb_course_market"

        db = DbHander.DBREAD()
        Cur = db.cursor()

        # 资源
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                # print("minfo_list",minfo_list)
                pid = int(minfo_list[1])
                version = int(minfo_list[12])
                uid = int(minfo_list[10])
                pids.append([pid, uid])
                if uid not in _server_pid.keys():
                    _server_pid[uid] = []
                _server_pid[uid].append(pid)
                if uid not in p_server or pid not in p_server[uid] or version > p_server[uid][pid]:
                    # 这里才同步
                    if _back == "":
                        if len(temp_post) > 0:
                            _back = _back+ "!"
                        _back = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + minfo_list[5] + "`" + str(minfo_list[6]) + "`" + minfo_list[7] + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + str(minfo_list[17]) + "``" + str(minfo_list[18])
                    else:
                        _back = _back + "!" + str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + minfo_list[5] + "`" + str(minfo_list[6]) + "`" + minfo_list[7] + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + str(minfo_list[17]) + "``" + str(minfo_list[18])
                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_back)
                        _back = ""


        sdelete = ""
        if itype == 2:
            for _c_uid in p_server.keys():
                values = p_server[_c_uid]
                for _c_pid in values.keys():
                    if _c_uid not in _server_pid or _c_pid not in _server_pid[_c_uid]:
                        # 这里需要删除的工程
                        if sdelete == "":
                            sdelete = str(_c_uid) + "`" + str(_c_pid)
                        else:
                            sdelete = sdelete + "!" + str(_c_uid) + "`" + str(_c_pid)
                # DEBUG_MSG("需要删除课程：", sdelete,_server_pid,p_server)
        _back = _back + "！" + sdelete + "="
        temp_post.append(_back)
        # _lback.append(pids)
        # _lback.append(_back)

        ipos = 0
        _back = ""
        if len(pids) >= 1:
            obj_dic = {}
            _all_s_string = ""
            for li in pids:
                pid = li[0]
                uid = li[1]
                if objtype == 0:
                    table_name = Global.GetLessonTableName(uid, pid)
                else:
                    table_name = Global.GetMLessonTableName(uid, pid)
                # 1`1!2`1
                obj_dic = {}
                #print("obj_server",obj_server)
                if uid in obj_server.keys():
                    if pid in obj_server[uid].keys():
                        str_p = obj_server[uid][pid]
                        l_pdata = str_p.split('!')
                        for str_p_i in l_pdata:
                            d_data = str_p_i.split('`')
                            obj_dic[int(d_data[0])] = int(d_data[1])
                sql = "select * from " + table_name
                Cur.execute(sql)
                db.commit()
                data = Cur.fetchall()
                _cback = ""

                if data != None and len(data) > 0:
                    list_data = list(data)
                    if _all_s_string != "":
                        _all_s_string = _all_s_string + "^" + str(uid) + "`" + str(pid) + "`"
                    else:
                        _all_s_string = str(uid) + "`" + str(pid) + "`"
                    _lid_strs = ""
                    for minfo in list_data:
                        minfo_list = list(minfo)
                        #DEBUG_MSG("minfo_list", minfo_list)
                        Lid = int(minfo_list[1])
                        if _lid_strs == "":
                            _lid_strs = str(Lid)
                        else:
                            _lid_strs = _lid_strs + "," + str(Lid)

                        version = int(minfo_list[17])
                        if len(obj_dic) > 0 and Lid in obj_dic and version <= obj_dic[Lid]:
                            continue
                        # 这里才同步
                        if _cback == "":
                            _cback = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + minfo_list[6] + "`" +minfo_list[7] + "`" + minfo_list[8] + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + str(minfo_list[17])+ "`" + str(minfo_list[18])+ "`" + str(minfo_list[19])+ "`" + str(minfo_list[20])
                        else:
                            _cback = _cback + "!" + str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + minfo_list[6] + "`" +minfo_list[7] + "`" + minfo_list[8] + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + str(minfo_list[17])+ "`" + str(minfo_list[18])+ "`" + str(minfo_list[19])+ "`" + str(minfo_list[20])
                    _all_s_string = _all_s_string + _lid_strs
                if _cback != "":
                    if _back == "":
                        if len(temp_post) > 0:
                            _back = _back+ "!"
                        _back = str(pid) + "^" + str(uid) + "^" + _cback
                    else:
                        _back = _back + "*" + str(pid) + "^" + str(uid) + "^" + _cback

                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_back)
                        _back = ""

            _back = _back + "！" + _all_s_string
            temp_post.append(_back)
        db.close()
        return temp_post






    def GetPDataWVersion(self, pdata, theuid, type=0):

        temp_post = []
        _server_pid = {}
        _back = ""
        p_server = {}
        if pdata != None and len(pdata) > 0:
            l_pdata = pdata.split('*')
            for info in l_pdata:
                sdata = info.split('^')
                uid = int(sdata[0])
                pid = int(sdata[1])
                version = int(sdata[2])
                if uid not in p_server.keys():
                    p_server[uid] = {}
                p_server[uid][pid] = version

        #self.db_ping
        db = DbHander.DBREAD()
        Cur = db.cursor()

        AccountType = 0
        sql = "select AccountType from tb_userdata where UID = " + str(theuid) + ";"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchone()
        if data != None and len(data) > 0:
            AccountType = int(data[0])
        # DEBUG_MSG("1 - p_server : [%s]" % p_server)
        table_name = ""
        if type == 0:
            table_name = "tb_project"
        else:
            table_name = "tb_mproject"
        if type == 0:
            if AccountType == 1:
                sql = "select * from tb_project where UID = " + str(theuid)
            else:
                sql = "select * from tb_project where UID = " + str(theuid) + " AND Template < 10000 union ALL SELECT T1.* FROM tb_project AS T1 inner join (select TID,CID+10000 AS CID FROM tb_class AS T5 WHERE FIND_IN_SET(T5.CID, (SELECT CLASSID FROM tb_userdata where UID = " + str(theuid) + " )))  as T2 ON T1.UID = T2.TID AND T1.Template = T2.CID;"
            # sql = "select * from "+table_name+" where uid = "+str(self.databaseID)  #自由工程数据
        elif type == 1:
            sql = "select * from " + table_name + " where P_TYPE = 1"  # 课程中的工程
        elif type == 2:
            sql = "select * from " + table_name + " where P_TYPE = 0"  # 作品中的工程数据
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        ipos = 0
        if len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                # print("minfo_list",minfo_list)
                pid = int(minfo_list[1])
                _pid = pid
                version = int(minfo_list[24])
                uid = int(minfo_list[25])
                template = int(minfo_list[13])
                if type == 0 and theuid != uid:
                    pid = 10000000 + uid * 100 + pid
                # if type==0:
                #     #if int(minfo_list[26]) == 0:   #去掉这个购买判断，购买的也是出现在自有工厂
                #      pids.append([_pid,uid])  #只有自由工程
                # else:
                #     pids.append([_pid, uid])  # 只有自由工程
                if uid not in _server_pid.keys():
                    _server_pid[uid] = []
                _server_pid[uid].append(pid)
                if uid not in p_server or pid not in p_server[uid] or version > p_server[uid][pid]:
                    # 这里才同步
                    if _back == "":
                        if len(temp_post) > 0:
                            _back = _back+ "!"
                        _back = _back + str(pid) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + minfo_list[15] + "`" + minfo_list[16] + "`" + str(minfo_list[17]) + "`" + str(minfo_list[18]) + "`" + minfo_list[19] + "`" + str(minfo_list[20]) + "`" + str(minfo_list[21]) + "`" + str(minfo_list[22]) + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + str(minfo_list[25]) + "`" + str(minfo_list[26]) + "`" + str(minfo_list[27]) + "`" + str(minfo_list[28])
                    else:
                        _back = _back + "!" + str(pid) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + minfo_list[15] + "`" + minfo_list[16] + "`" + str(minfo_list[17]) + "`" + str(minfo_list[18]) + "`" + minfo_list[19] + "`" + str(minfo_list[20]) + "`" + str(minfo_list[21]) + "`" + str(minfo_list[22]) + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + str(minfo_list[25]) + "`" + str(minfo_list[26]) + "`" + str(minfo_list[27]) + "`" + str(minfo_list[28])
                    ipos+=1
                    if ipos%self.OnePageNum == 0:
                        temp_post.append(_back)
                        _back=""



        sdelete = ""
        if type == 0:
            for _c_uid in p_server.keys():
                values = p_server[_c_uid]
                for _c_pid in values.keys():
                    if _c_uid not in _server_pid or _c_pid not in _server_pid[_c_uid]:
                        if _c_uid == theuid:
                            continue
                        # 这里需要删除的工程
                        if sdelete == "":
                            sdelete = str(_c_uid) + "`" + str(_c_pid)
                        else:
                            sdelete = sdelete + "!" + str(_c_uid) + "`" + str(_c_pid)
                # DEBUG_MSG("需要删除工程：",sdelete)
        _back = _back + "！" + sdelete
        temp_post.append(_back)
        db.close()
        # _lback.append(pids)
        return temp_post

    def GetWDataWithVersion(self,pdata,TheUID,type):
        p_server = {}
        temp_post = []
        ipos = 0
        if pdata != None and len(pdata) > 0:
            l_pdata = pdata.split('!')
            for info in l_pdata:
                sdata = info.split('`')
                uid = int(sdata[0])
                pid = int(sdata[1])
                version = int(sdata[2])
                if uid not in p_server.keys():
                    p_server[uid] = {}
                p_server[uid][pid] = version
        _lback = []
        _server_pid = {}
        _back = ""
        sdelete = ""
        if type == 0:
            sql = "select *,'' from tb_workbag where UID = " + str(TheUID)
        elif type == 1:  # 作品市场
            sql = "select T1.*,T2.username from tb_workmarket t1 inner join tb_userdata t2 on t1.UID = t2.UID;"
            # sql = "select * from tb_workmarket"
        db = DbHander.DBREAD()
        Cur = db.cursor()
        # 资源
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                # print("minfo_list",minfo_list)
                uid = int(minfo_list[11])
                pid = int(minfo_list[1])
                version = int(minfo_list[14])

                if uid not in _server_pid.keys():
                    _server_pid[uid] = []
                _server_pid[uid].append(pid)

                if uid not in p_server or pid not in p_server[uid] or version > p_server[uid][pid]:
                    # 这里才同步
                    if _back == "":
                        if len(temp_post) > 0:
                            _back = _back+ "!"
                        _back = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + minfo_list[7] + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + minfo_list[17] + "`" + minfo_list[18] + "`" + minfo_list[19] + "`" + minfo_list[27] + "`" + str(minfo_list[20]) + "`" + str(minfo_list[21]) + "`" + str(minfo_list[22]) + "`" + str(minfo_list[23])
                    else:
                        _back = _back + "!" + str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + minfo_list[7] + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + str(minfo_list[15]) + "`" + str(minfo_list[16]) + "`" + minfo_list[17] + "`" + minfo_list[18] + "`" + minfo_list[19] + "`" + minfo_list[27] + "`" + str(minfo_list[20]) + "`" + str(minfo_list[21]) + "`" + str(minfo_list[22]) + "`" + str(minfo_list[23])
                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_back)
                        _back = ""


        if type == 1:
            for _c_uid in p_server.keys():
                values = p_server[_c_uid]
                for _c_pid in values.keys():
                    if _c_uid not in _server_pid or _c_pid not in _server_pid[_c_uid]:
                        # 这里需要删除的工程
                        if sdelete == "":
                            sdelete = str(_c_uid) + "`" + str(_c_pid)
                        else:
                            sdelete = sdelete + "!" + str(_c_uid) + "`" + str(_c_pid)

                # DEBUG_MSG("需要删除的作品市场：" + sdelete)
        _back = _back + "！" + sdelete
        temp_post.append(_back)
        db.close()
        return temp_post


class post_pcheckHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #工程数据版本号获取
    def post(self):

        UID = self.POST_VERIFY_MAIN

        if UID > 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Data = {}

            # BODY=====================================
            #self.db_ping
            db = DbHander.DBREAD()
            Cur = db.cursor()

            JDATA = json.loads(self.JData)
            gpid = JDATA["gpid"]
            guid = JDATA["guid"]
            gtype = int(JDATA["gtype"])
            print("JSON_Data2:", JSON_Data)
            table_project = ""
            table_obj = ""
            if gtype == 0:
                table_project = "tb_project"
            else:
                table_project = "tb_mproject"
            #获取工程数据版本号
            sql_str = "select version from "+table_project+" where UID = "+str(guid)+" AND PID = "+str(gpid)
            print("sql_str : ", sql_str)
            Cur.execute(sql_str)
            db.commit()
            data = Cur.fetchone()
            if data != None and len(data) > 0:
                JSON_Bck["Code"] = 1
                JSON_Bck["Msg"] = "OK"
                JSON_Bck["Data"] = str(data[0])
            else:
                JSON_Bck["Code"] = 0
                JSON_Bck["Msg"] = "工程不存在"
                JSON_Bck["Data"] = ""
            # BODY=====================================

            print("JSON_Data1:",JSON_Data)
            db.close()
            self.write(JSON_Bck)


class post_pdataIniHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #工程数据获取
    def post(self):
        UID = self.POST_VERIFY_MAIN
        if UID > 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)
            JSON_Data = ""

            # BODY=====================================
            #self.db_ping
            db = DbHander.DBREAD()
            Cur = db.cursor()
            JDATA = json.loads(self.JData)
            gpid = JDATA["gpid"]
            guid = JDATA["guid"]
            gtype = int(JDATA["gtype"])
            type1 = JDATA["type1"]
            type2 = JDATA["type2"]
            type3 = JDATA["type3"]

            JSON_Data = str(gpid)+"！"+str(guid)+"！"+str(gtype)+"！"

            table_project = ""
            table_obj = ""
            data_project = ""
            data_obj = ""
            _version = 0
            if gtype == 0:
                table_project = "tb_project"
                table_obj = "tb_obj_" + str(guid) + "_" + str(gpid)
            else:
                table_project = "tb_mproject"
                table_obj = "tb_mobj_" + str(guid) + "_" + str(gpid)
            # 获取工程数据版本号
            sql_str = "select * from " + table_project + " where UID = " + str(guid) + " and PID = " + str(gpid) + ";"
            Cur.execute(sql_str)
            db.commit()
            minfo_list = Cur.fetchone()
            if minfo_list != None and len(minfo_list) > 0:
                _version = int(minfo_list[24])
                data_project = _back = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + str(minfo_list[14]) + "`" + minfo_list[15] + "`" + minfo_list[16] + "`" + str(minfo_list[17]) + "`" + str(minfo_list[18]) + "`" + minfo_list[19] + "`" + str(minfo_list[20]) + "`" + str(minfo_list[21]) + "`" + str(minfo_list[22]) + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24])+ "`" + str(minfo_list[25])+ "`" + str(minfo_list[26])+ "`" + str(minfo_list[27])+ "`" + str(minfo_list[28])
            else:
                db.close()
                JSON_Bck["Code"] = 0
                JSON_Bck["Msg"] = "工程不存在"
                JSON_Data = JSON_Data + + str(_version) + "！" + str(type1) + "！" + str(type2) + "！" + str(type3) + "！" + data_project + "！" + data_obj
                JSON_Bck["Data"] = JSON_Data
                self.write(JSON_Bck)
                return

            #获取资源数据
            sql_str = "select * from " + table_obj + " where bdelete = 0;"
            Cur.execute(sql_str)
            db.commit()
            lines = Cur.fetchall()
            _pos = 0
            _cback = ""
            if lines and len(lines) > 0:
                for minfo_list in lines:
                    if _cback == "":
                        _cback = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + minfo_list[14] + "`" + minfo_list[15].decode() + "`" + minfo_list[16] + "`" + minfo_list[17] + "`" + str(minfo_list[18]) + "`" + str(minfo_list[19]) + "`" + str(minfo_list[20]) + "`" + minfo_list[21] + "`" + minfo_list[22] + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + minfo_list[25] + "`" + str(minfo_list[26]) + "`" + str(minfo_list[27]) + "`" + str(minfo_list[28])
                    else:
                        _cback = _cback + "!" + str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + minfo_list[14] + "`" + minfo_list[15].decode() + "`" + minfo_list[16] + "`" + minfo_list[17] + "`" + str(minfo_list[18]) + "`" + str(minfo_list[19]) + "`" + str(minfo_list[20]) + "`" + minfo_list[21] + "`" + minfo_list[22] + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + minfo_list[25] + "`" + str(minfo_list[26]) + "`" + str(minfo_list[27]) + "`" + str(minfo_list[28])
                if _cback != "":
                    data_obj = str(gpid) + "^" + str(guid) + "^" + _cback

                # sql_str = "select sum(v) from(select version as v from " + table_project + " where UID = " + str(guid) + " AND PID = " + str(gpid) + " union all SELECT sum(version) as v from " + table_obj + " where bdelete = 0) t;"
                # self.Cur.execute(sql_str)
                # self.db.commit()
                # data = self.Cur.fetchone()
                # if data != None and len(data) > 0:
                #     JSON_Data = JSON_Data +str(data[0])+"！"

                JSON_Data = JSON_Data + str(_version) + "！" + str(type1) + "！" + str(type2) + "！" + str(type3) + "！" + data_project + "！" + data_obj

                JSON_Bck["Code"] = 1
                JSON_Bck["Msg"] = "OK"
                JSON_Bck["Data"] = JSON_Data
            else:
                JSON_Bck["Code"] = 0
                JSON_Bck["Msg"] = "资源不存在"
                JSON_Data = JSON_Data + str(_version) + "！" + str(type1) + "！" + str(type2) + "！" + str(type3) + "！" + data_project + "！" + data_obj
                JSON_Bck["Data"] = JSON_Data

            # BODY=====================================
            db.close()


            self.write(JSON_Bck)