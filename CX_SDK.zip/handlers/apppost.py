#!/usr/bin/env python
# coding=utf-8

import logging
import copy
import Global
import json
from handlers.base import BaseHandler
from methods.db_mysql import DbHander

class apppost_LoginINIHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #工程列表
    def post(self):

        UID = self.POST_VERIFY_MAIN

        p_back = ""
        if UID > 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)

            print("self.JData",self.JData)

            # BODY=====================================
            # 获取 工程列表
            JDATA = json.loads(self.JData)
            read_type = int(JDATA["rtype"])
            read_page = int(JDATA["page"])

            if read_page == 1:
                if read_type == 1:  #自由工程数据
                    self.post_data_temp_set(UID,self.GetLoginData(UID,JDATA["data"]))

            post_data_temp = self.post_data_temp_get(UID)
            ionly = len(post_data_temp) - read_page

            JSON_Bck["Code"] = 1
            JSON_Bck["Data"] = post_data_temp[read_page - 1]
            JSON_Bck["Msg"] = str(ionly)

            self.write(JSON_Bck)


    def GetLoginData(self,_uid ,RequestData):

        _course_string = ""
        _project_string = ""
        _userdata_string = ""
        _work_string = ""
        _worklook_string = ""

        ipos = 0
        temp_post = []

        read_data = json.loads(RequestData)
        accountPower = int(read_data["accountpower"])
        appType = int(read_data["apptype"])

        #self.db_ping
        db = DbHander.DBREAD()
        Cur = db.cursor()

        AccountType = 0
        sql = "select AccountType from tb_userdata where UID = "+str(_uid)+";"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchone()
        if data != None and len(data) > 0:
            AccountType = int(data[0])

        sql = "select T3.*,T4.UserName from (select T2.CID AS a,T1.`Name` as b,T1.UID as d,T1.CID as e,T1.pic as f,t1.ct,t1.ZK1,t1.ZK2,t1.Platform from tb_course_market t1 inner join tb_course_bag t2 on t2.P_CID = T1.CID AND T2.P_UID = T1.UID and t2.UID = " + str(_uid) + " ) t3 left join tb_userdata as t4 on t3.d = t4.UID;"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if data != None and len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)

                if minfo_list[0] == None:
                    _cid = 0
                else:
                    _cid = minfo_list[0]
                _name = minfo_list[1]
                _P_UID = minfo_list[2]
                _P_CID = minfo_list[3]
                _PIC = minfo_list[4]
                _ct = minfo_list[5]
                _ZK1 = minfo_list[6]
                _ZK2 = minfo_list[7]
                _platform = minfo_list[8]

                if minfo_list[9] == None:
                    _CName = ""
                else:
                    _CName = minfo_list[9]

                if _course_string == "":
                    if len(_course_string) > 0:
                        _course_string = _course_string + "!"
                    _course_string = str(_cid) + "^" + _name + "^" + str(_uid) + "^" + str(_P_UID) + "^" + str(_P_CID) + "^" + _PIC + "^" + _CName + "^" + str(_ct) + "^" + str(_ZK1) + "^" + str(_ZK2) + "^" + str(_platform) + "^" + self.GetLessonData(_uid, _cid, _P_UID, _P_CID, appType)
                else:
                    _course_string = _course_string + "!" + str(_cid) + "^" + _name + "^" + str(_uid) + "^" + str(_P_UID) + "^" + str(_P_CID) + "^" + _PIC + "^" + _CName + "^" + str(_ct) + "^" + str(_ZK1) + "^" + str(_ZK2) + "^" + str(_platform) + "^" + self.GetLessonData(_uid, _cid, _P_UID,_P_CID, appType)
                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_course_string)
                        _course_string = ""
                    # DEBUG_MSG("_course_string : " + _course_string)

        _course_string = _course_string + "*"
        if _course_string != "":
            temp_post.append(_course_string)
        ipos = 0

        # 自由工程数据
        if AccountType == 1:
            sql = "select PID,UID,PNAME,SID,HTYPE,P_UID,ParentPid,template,CreateDate from tb_project where UID = " + str(_uid)
        else:
            sql = "select PID,UID,PNAME,SID,HTYPE,P_UID,ParentPid,template,CreateDate from tb_project where UID = " + str(_uid) + " AND Template < 10000 and template in (0,3,4) union ALL SELECT T1.PID,T1.UID,T1.PNAME,T1.SID,T1.HTYPE,T1.P_UID,T1.ParentPid,T1.template,T1.CreateDate FROM tb_project AS T1 inner join (select TID,CID+10000 AS CID FROM tb_class  AS T5 WHERE FIND_IN_SET(T5.CID, (SELECT CLASSID FROM tb_userdata where UID = " + str(_uid) + " )))  as T2 ON T1.UID = T2.TID AND T1.Template = T2.CID order by CreateDate desc;"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if data != None and len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)

                _pid = minfo_list[0]
                _theuid = minfo_list[1]
                _name = minfo_list[2]
                _sid = minfo_list[3]
                _htype = minfo_list[4]
                _P_UID = minfo_list[5]
                _ParentPid = minfo_list[6]
                _template = minfo_list[7]
                _CreateDate = minfo_list[8]

                if _project_string == "":
                    if len(_project_string) > 0:
                        _project_string = _project_string + "!"
                    _project_string = str(_pid) + "^" + _name + "^" + str(_theuid) + "^" + str(_sid) + "^" + str(_htype) + "^" + str(_P_UID) + "^" + str(_ParentPid) + "^" + str(_template) + "^" + str(_CreateDate)
                else:
                    _project_string = _project_string + "!" + str(_pid) + "^" + _name + "^" + str(_theuid) + "^" + str(_sid) + "^" + str(_htype) + "^" + str(_P_UID) + "^" + str(_ParentPid) + "^" + str(_template) + "^" + str(_CreateDate)
                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_project_string)
                        _project_string = ""

        _project_string = _project_string + "*"
        if _project_string != "":
            temp_post.append(_project_string)
        ipos = 0


        # 共享作品数据
        # if self.Power == 0:     #C端才有共享大厅
        sql = "select T3.*,T4.UserName from (select PID  ,`Name`,uid ,`desc`,ct,SID,Wid,price2,Platform,CreateDate,stime,etime from tb_workmarket) t3 inner join tb_userdata as t4 on t3.uid = t4.UID;"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if data != None and len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)

                _pid = minfo_list[0]
                if _pid == None:
                    _pid = 0
                _name = minfo_list[1]
                _puid = minfo_list[2]
                _desc = minfo_list[3]
                _ct = minfo_list[4]
                _SID = minfo_list[5]
                _wid = minfo_list[6]
                _price = minfo_list[7]
                _platform = minfo_list[8]
                _CreateDate = minfo_list[9]
                _stime = minfo_list[10]
                _etime = minfo_list[11]
                _bname = minfo_list[12]

                if _work_string == "":
                    if len(_work_string) > 0:
                        _work_string = _work_string + "!"
                    _work_string = str(_pid) + "^" + _name + "^" + str(_puid) + "^" + _desc + "^" + _bname + "^" + str(_ct) + "^" + str(_SID) + "^" + str(_wid) + "^" + str(_price) + "^" + str(_platform) + "^" + str(_CreateDate) + "^" + str(_stime) + "^" + str(_etime)
                else:
                    _work_string = _work_string + "!" + str(_pid) + "^" + _name + "^" + str(_puid) + "^" + _desc + "^" + _bname + "^" + str(_ct) + "^" + str(_SID) + "^" + str(_wid) + "^" + str(_price) + "^" + str(_platform) + "^" + str(_CreateDate) + "^" + str(_stime) + "^" + str(_etime)
                    ipos += 1
                    if ipos % self.OnePageNum == 0:
                        temp_post.append(_work_string)
                        _work_string = ""

        _work_string = _work_string + "*"
        if _work_string != "":
            temp_post.append(_work_string)
        ipos = 0


        # 买看数据
        if accountPower == 0:  # C端才买看数据
            sql = "select * from tb_work_look_b where UID = " + str(_uid) + ""
            Cur.execute(sql)
            db.commit()
            data = Cur.fetchall()
            if data != None and len(data) > 0:
                list_data = list(data)
                for minfo in list_data:
                    minfo_list = list(minfo)
                    if _worklook_string == "":
                        _worklook_string = str(minfo_list[3]) + "^" + str(minfo_list[2]) + "^" + str(minfo_list[4])
                    else:
                        _worklook_string = _worklook_string + "!" + str(minfo_list[3]) + "^" + str(minfo_list[2]) + "^" + str(minfo_list[4])


        # 频道包月数据
        _channel_string = ""
        if accountPower == 0:
            sql = "select * from tb_channel_buy where UID = " + str(_uid) + ""
            Cur.execute(sql)
            db.commit()
            data = Cur.fetchall()
            if data != None and len(data) > 0:
                list_data = list(data)
                for minfo in list_data:
                    minfo_list = list(minfo)
                    if _channel_string == "":
                        _channel_string = str(minfo_list[1]) + "^" + str(minfo_list[2])
                    else:
                        _channel_string = _channel_string + "!" + str(minfo_list[1]) + "^" + str(minfo_list[2])

        temp_post.append(_worklook_string+"*"+_channel_string)
        #DEBUG_MSG("_userdata_string", _userdata_string)
        # print("_course_string", _course_string)
        # print("_project_string", _project_string)
        # print("_work_string",_work_string)
        # print("_worklook_string", _worklook_string)   #wid^uid^时间!
        # print("_channel_string", _channel_string)
        db.close()
        return temp_post #_course_string + "*" + _project_string + "*" + _work_string + "*" + _worklook_string + "*" + _channel_string


    def GetLessonData(self,_uid,_cid , _puid , _pcid,appType):

        #DEBUG_MSG("GetLessonData",_uid,_cid , _puid , _pcid)
        #_cid 为0 表示这个课程未购买，是课程市场中的课程
        db = DbHander.DBREAD()
        Cur = db.cursor()
        _back = ""
        table_name = "tb_lesson_"+str(_uid)+"_"+str(_cid)
        #table_name2 = "tb_mlesson_"+str(_puid)+"_"+str(_pcid)
        #380 203 24 3
        # if _cid != 0:
        #     sql = "select t1.LID,t2.UID,t2.PID,t2.PIC,t2.`NAME`,t1.P1,t1.P2,t1.P3,t1.P4,t2.LID,t2.Price,t2.PriceAll,t1.CreateDate from "+table_name+" as t1 right join "+table_name2+" as t2 on t1.LID = t2.LID AND (t1.PDATE >= unix_timestamp(now()) or t1.PDATE = 1);"
        # else:
        #     sql = "select 0,UID,PID,PIC,`NAME`,0,0,0,0,LID,Price,PriceAll,CreateDate from " + table_name2    #市场里面的课时
        sql = "select LID,UID,PID,PIC,`NAME`,P1,P2,P3,P4,0,0,0,CreateDate from "+table_name+";"
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if data != None and len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                if _back == "":
                    _back = str(minfo_list[0]) + "`"+str(minfo_list[1]) + "`"+str(minfo_list[2]) + "`"+minfo_list[3] + "`"+minfo_list[4] + "`"+str(minfo_list[5]) + "`"+str(minfo_list[6]) + "`"+str(minfo_list[7]) + "`"+str(minfo_list[8])+ "`"+str(minfo_list[9])+ "`"+str(minfo_list[10])+ "`"+str(minfo_list[11])+ "`"+str(minfo_list[12])
                else:
                    _back =  _back + "^" + str(minfo_list[0]) + "`" + str(minfo_list[1]) + "`" + str(minfo_list[2]) + "`" + minfo_list[3] + "`" + minfo_list[4] + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8])+ "`"+str(minfo_list[9])+ "`"+str(minfo_list[10])+ "`"+str(minfo_list[11])+ "`"+str(minfo_list[12])
        db.close()
        return _back


class apppost_PDataINIHandler(BaseHandler):    #继承base.py中的类BaseHandler

    #工程列表
    def post(self):

        UID = self.POST_VERIFY_MAIN

        p_back = ""
        if UID > 0:
            JSON_Bck = copy.deepcopy(Global.JSON_Bck)

            print("self.JData",self.JData)

            # BODY=====================================
            # 获取 工程列表
            JDATA = json.loads(self.JData)
            uid = int(JDATA["uid"])
            pid = int(JDATA["pid"])
            ismarket = int(JDATA["ismarket"])
            #self.db_ping

            p_string = self.ReadPData(pid, uid, ismarket)
            obj_string = self.ReadObjData(pid, uid, ismarket)
            p_back = str(ismarket) + "!" + p_string + "!" + obj_string

            JSON_Bck["Code"] = 1
            JSON_Bck["Msg"] = "OK"
            JSON_Bck["Data"] = p_back

            self.write(JSON_Bck)


    def ReadPData(self,pid,uid,ismarket):
        _back = ""
        if ismarket == 0:
            table_name = "tb_project"
        else:
            table_name = "tb_mproject"

        sql = "select PID,UID,PNAME,C_POSX,C_POSY,C_POSZ,C_RotX,C_RotY,C_RotZ,LightIntensity,LightColor,LightAngle,SID from " + table_name + " where UID = " + str(uid) + " and PID = " + str(pid) + ";"
        #DEBUG_MSG("sql : " , sql)
        db = DbHander.DBREAD()
        Cur = db.cursor()
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchone()
        if data != None and len(data) > 0:
            _back = str(data[0]) + "`" + str(data[1])+ "`" + data[2]+ "`" + str(data[3])+ "`" + str(data[4])+ "`" + str(data[5])+ "`" + str(data[6])+ "`" + str(data[7])+ "`" + str(data[8])+ "`" + str(data[9])+ "`" + data[10]+ "`" + data[11]+ "`" + str(data[12])
        db.close()
        return _back

    def ReadObjData(self,pid,uid,ismarket):
        _cback = ""
        if ismarket == 0:
            table_name = "tb_obj_"+str(uid)+"_"+str(pid)
        else:
            table_name = "tb_mobj_"+str(uid)+"_"+str(pid)
        sql = "select * from " + table_name + " where bdelete = 0;"
        db = DbHander.DBREAD()
        Cur = db.cursor()
        Cur.execute(sql)
        db.commit()
        data = Cur.fetchall()
        if data != None and len(data) > 0:
            list_data = list(data)
            for minfo in list_data:
                minfo_list = list(minfo)
                if minfo_list[15] == None:
                    minfo_list[15] = b""
                if _cback == "":
                    _cback = str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + minfo_list[14] + "`" + minfo_list[15].decode() + "`" + minfo_list[16] + "`" + minfo_list[17] + "`" + str(minfo_list[18]) + "`" + str(minfo_list[19]) + "`" + str(minfo_list[20]) + "`" + minfo_list[21] + "`" + minfo_list[22] + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + minfo_list[25] + "`" + str(minfo_list[26])
                else:
                    _cback =_cback + "^" + str(minfo_list[1]) + "`" + minfo_list[2] + "`" + str(minfo_list[3]) + "`" + str(minfo_list[4]) + "`" + str(minfo_list[5]) + "`" + str(minfo_list[6]) + "`" + str(minfo_list[7]) + "`" + str(minfo_list[8]) + "`" + str(minfo_list[9]) + "`" + str(minfo_list[10]) + "`" + str(minfo_list[11]) + "`" + str(minfo_list[12]) + "`" + str(minfo_list[13]) + "`" + minfo_list[14] + "`" + minfo_list[15].decode() + "`" + minfo_list[16] + "`" + minfo_list[17] + "`" + str(minfo_list[18]) + "`" + str(minfo_list[19]) + "`" + str(minfo_list[20]) + "`" + minfo_list[21] + "`" + minfo_list[22] + "`" + str(minfo_list[23]) + "`" + str(minfo_list[24]) + "`" + minfo_list[25] + "`" + str(minfo_list[26])
        db.close()
        return _cback